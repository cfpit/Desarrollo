package ar.edu.centro8.desarrollo.proyectoauto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoAutoApplicationTests {

	@Test
	void contextLoads() {
	}

}