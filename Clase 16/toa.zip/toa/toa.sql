	create table cursos (
        id_curso bigint not null auto_increment,
        nombre varchar(255) not null,
        primary key (id_curso)
    ) engine=InnoDB
 
 
 
    create table estudiantes (
        id_estudiante bigint not null auto_increment,
        apellido varchar(255) not null,
        primary key (id_estudiante)
    ) engine=InnoDB

    

    create table inscripciones (
        estado enum ('ABANDONADA','ACTIVA','COMPLETADA','EN_PROGRESO') not null,      
        fecha_inscripcion date not null,
        id_curso bigint not null,
        id_estudiante bigint not null,
        primary key (id_curso, id_estudiante)
    ) engine=InnoDB


    alter table inscripciones
       add constraint FKmyps0lutv0v9xqttbepwe14jt
       foreign key (id_curso)
       references cursos (id_curso)

   
    alter table inscripciones
       add constraint FKek59i6fh86qxytodhvtvsfkv9
       foreign key (id_estudiante)
       references estudiantes (id_estudiante)


    