package ar.edu.centro8.daw.toa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToaApplication.class, args);
	}

}
