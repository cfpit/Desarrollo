package ar.edu.centro8.daw.toa.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "inscripciones")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Inscripcion {

    @EmbeddedId
    private InscripcionId id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @MapsId("idEstudiante")
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @MapsId("idCurso")
    @JoinColumn(name = "id_curso")
    private Curso curso;    
    
    // Atributos propios de la tabla de enlace (TOA)
    @Column(name = "fecha_inscripcion", nullable = false)
    private LocalDate fechaInscripcion;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoInscripcion estado;

    public enum EstadoInscripcion {
        ACTIVA,
        COMPLETADA,
        ABANDONADA,
        EN_PROGRESO
    }

}
