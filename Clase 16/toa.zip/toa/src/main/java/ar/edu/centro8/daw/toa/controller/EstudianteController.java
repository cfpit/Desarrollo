package ar.edu.centro8.daw.toa.controller;

import ar.edu.centro8.daw.toa.model.Estudiante;
import ar.edu.centro8.daw.toa.repository.EstudianteRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteRepository estudianteRepository;

    @GetMapping
    public ResponseEntity<List<Estudiante>> getAllEstudiantes() {
        List<Estudiante> estudiantes = estudianteRepository.findAll();
        return ResponseEntity.ok(estudiantes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Estudiante> getEstudianteById(@PathVariable Long id) {
        return estudianteRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Estudiante> createEstudiante(@Valid @RequestBody Estudiante estudiante) {
        if (estudiante.getIdEstudiante() != null) {
            return ResponseEntity.badRequest().build();
        }
        Estudiante savedEstudiante = estudianteRepository.save(estudiante);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedEstudiante);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Estudiante> updateEstudiante(
            @PathVariable Long id,
            @Valid @RequestBody Estudiante estudianteDetails) {
        
        return estudianteRepository.findById(id)
                .map(estudiante -> {
                    estudiante.setApellido(estudianteDetails.getApellido());
                    Estudiante updatedEstudiante = estudianteRepository.save(estudiante);
                    return ResponseEntity.ok(updatedEstudiante);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Estudiante> partialUpdateEstudiante(
            @PathVariable Long id,
            @RequestBody Estudiante estudianteDetails) {
        
        return estudianteRepository.findById(id)
                .map(estudiante -> {
                    if (estudianteDetails.getApellido() != null) {
                        estudiante.setApellido(estudianteDetails.getApellido());
                    }
                    Estudiante updatedEstudiante = estudianteRepository.save(estudiante);
                    return ResponseEntity.ok(updatedEstudiante);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEstudiante(@PathVariable Long id) {
        return estudianteRepository.findById(id)
                .map(estudiante -> {
                    estudianteRepository.delete(estudiante);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
