package ar.edu.centro8.daw.toa.controller;

import ar.edu.centro8.daw.toa.model.Inscripcion;
import ar.edu.centro8.daw.toa.model.InscripcionId;
import ar.edu.centro8.daw.toa.repository.CursoRepository;
import ar.edu.centro8.daw.toa.repository.EstudianteRepository;
import ar.edu.centro8.daw.toa.repository.InscripcionRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inscripciones")
public class InscripcionController {

    @Autowired
    private InscripcionRepository inscripcionRepository;

    @Autowired
    private EstudianteRepository estudianteRepository;

    @Autowired
    private CursoRepository cursoRepository;

    @GetMapping
    public ResponseEntity<List<Inscripcion>> getAllInscripciones() {
        List<Inscripcion> inscripciones = inscripcionRepository.findAll();
        return ResponseEntity.ok(inscripciones);
    }

    @GetMapping("/estudiante/{estudianteId}")
    public ResponseEntity<List<Inscripcion>> getInscripcionesByEstudiante(@PathVariable Long estudianteId) {
        List<Inscripcion> inscripciones = inscripcionRepository.findByEstudianteId(estudianteId);
        return ResponseEntity.ok(inscripciones);
    }

    @GetMapping("/curso/{cursoId}")
    public ResponseEntity<List<Inscripcion>> getInscripcionesByCurso(@PathVariable Long cursoId) {
        List<Inscripcion> inscripciones = inscripcionRepository.findByCursoId(cursoId);
        return ResponseEntity.ok(inscripciones);
    }

    @GetMapping("/{idEstudiante}/{idCurso}")
    public ResponseEntity<Inscripcion> getInscripcionById(
            @PathVariable Long idEstudiante,
            @PathVariable Long idCurso) {
        
        InscripcionId id = new InscripcionId(idEstudiante, idCurso);
        return inscripcionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createInscripcion(@Valid @RequestBody Inscripcion inscripcion) {
        // Validar que existan el estudiante y el curso
        if (inscripcion.getId() == null || inscripcion.getId().getIdEstudiante() == null) {
            return ResponseEntity.badRequest().body("Debe especificar un estudiante");
        }
        if (inscripcion.getId().getIdCurso() == null) {
            return ResponseEntity.badRequest().body("Debe especificar un curso");
        }
        
        if (!estudianteRepository.existsById(inscripcion.getId().getIdEstudiante())) {
            return ResponseEntity.badRequest().body("Estudiante no encontrado");
        }
        if (!cursoRepository.existsById(inscripcion.getId().getIdCurso())) {
            return ResponseEntity.badRequest().body("Curso no encontrado");
        }

        // Cargar las entidades completas
        var estudiante = estudianteRepository.findById(inscripcion.getId().getIdEstudiante()).orElseThrow();
        var curso = cursoRepository.findById(inscripcion.getId().getIdCurso()).orElseThrow();
        
        inscripcion.setEstudiante(estudiante);
        inscripcion.setCurso(curso);

        Inscripcion savedInscripcion = inscripcionRepository.save(inscripcion);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedInscripcion);
    }

    @PutMapping("/{idEstudiante}/{idCurso}")
    public ResponseEntity<?> updateInscripcion(
            @PathVariable Long idEstudiante,
            @PathVariable Long idCurso,
            @Valid @RequestBody Inscripcion inscripcionDetails) {
        
        InscripcionId id = new InscripcionId(idEstudiante, idCurso);
        
        return inscripcionRepository.findById(id)
                .map(inscripcion -> {
                    inscripcion.setFechaInscripcion(inscripcionDetails.getFechaInscripcion());
                    inscripcion.setEstado(inscripcionDetails.getEstado());
                    Inscripcion updatedInscripcion = inscripcionRepository.save(inscripcion);
                    return ResponseEntity.ok(updatedInscripcion);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{idEstudiante}/{idCurso}")
    public ResponseEntity<?> partialUpdateInscripcion(
            @PathVariable Long idEstudiante,
            @PathVariable Long idCurso,
            @RequestBody Inscripcion inscripcionDetails) {
        
        InscripcionId id = new InscripcionId(idEstudiante, idCurso);
        
        return inscripcionRepository.findById(id)
                .map(inscripcion -> {
                    if (inscripcionDetails.getFechaInscripcion() != null) {
                        inscripcion.setFechaInscripcion(inscripcionDetails.getFechaInscripcion());
                    }
                    if (inscripcionDetails.getEstado() != null) {
                        inscripcion.setEstado(inscripcionDetails.getEstado());
                    }
                    Inscripcion updatedInscripcion = inscripcionRepository.save(inscripcion);
                    return ResponseEntity.ok(updatedInscripcion);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{idEstudiante}/{idCurso}")
    public ResponseEntity<Void> deleteInscripcion(
            @PathVariable Long idEstudiante,
            @PathVariable Long idCurso) {
        
        InscripcionId id = new InscripcionId(idEstudiante, idCurso);
        
        return inscripcionRepository.findById(id)
                .map(inscripcion -> {
                    inscripcionRepository.delete(inscripcion);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
