package ar.edu.centro8.daw.toa.repository;

import ar.edu.centro8.daw.toa.model.Inscripcion;
import ar.edu.centro8.daw.toa.model.InscripcionId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InscripcionRepository extends JpaRepository<Inscripcion, InscripcionId> {
    
    @Query("SELECT i FROM Inscripcion i WHERE i.estudiante.idEstudiante = :idEstudiante")
    List<Inscripcion> findByEstudianteId(Long idEstudiante);
    
    @Query("SELECT i FROM Inscripcion i WHERE i.curso.idCurso = :idCurso")
    List<Inscripcion> findByCursoId(Long idCurso);
    
    @Query("SELECT i FROM Inscripcion i WHERE i.estado = :estado")
    List<Inscripcion> findByEstado(Inscripcion.EstadoInscripcion estado);
}
