package ar.edu.centro8.daw.toa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToaApplicationTests {

	@Test
	void contextLoads() {
	}

}
