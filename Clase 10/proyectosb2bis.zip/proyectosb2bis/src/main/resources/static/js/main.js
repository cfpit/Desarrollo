function demo(){
    alert('Hola Thymeleaf!');
}