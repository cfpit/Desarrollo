package ar.edu.centro8.desarrollo.proyectosb2bis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class Proyectosb2bisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyectosb2bisApplication.class, args);
	}

}
