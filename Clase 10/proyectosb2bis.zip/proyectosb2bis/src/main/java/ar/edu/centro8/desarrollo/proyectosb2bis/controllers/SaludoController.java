package ar.edu.centro8.desarrollo.proyectosb2bis.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ResponseBody;

import ar.edu.centro8.desarrollo.proyectosb2bis.models.Cliente;



@Controller
public class SaludoController {

	//localhost:8080/main
    @GetMapping("/main")
	public String greeting(@RequestParam(name="nombre", required=false, defaultValue="World") String nombre, Model model){
		model.addAttribute("nombre",nombre);
		return "main";
	}

	//localhost:8080/welcome
	@GetMapping("/welcome")
	public String welcome(){
		return "welcome";
	}

	//localhost:8080/cliente/form - Mostrar formulario
	@GetMapping("/cliente/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("cliente", new Cliente());
		return "cliente-form";
	}

	//localhost:8080/cliente/procesar - Procesar formulario
	@PostMapping("/cliente/procesar")
	@ResponseBody
	public String procesarFormulario(@ModelAttribute Cliente cliente) {
		// Retornamos los datos como texto plano
		return "Datos recibidos:\n" +
			   "Nombre: " + cliente.getNombre() + "\n" +
			   "Edad: " + cliente.getEdad() + " años\n\n";
	}
}
