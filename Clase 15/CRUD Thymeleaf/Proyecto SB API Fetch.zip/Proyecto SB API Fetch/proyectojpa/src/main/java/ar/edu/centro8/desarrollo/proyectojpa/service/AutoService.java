package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.repository.IAutoRepository;

@Service
public class AutoService implements IAutoService {

    @Autowired
    private IAutoRepository autoRepo;
    
    @Override
    public List<Auto> getAutos() {
        List<Auto> listaAutos = autoRepo.findAll();
        return listaAutos;
    }

    @Override
    public void saveAuto(Auto auto) {
        autoRepo.save(auto);
    }

    @Override
    public void deleteAuto(Long id) {
        autoRepo.deleteById(id);
    }

    @Override
    public Auto findAuto(Long id) {
        Auto auto = autoRepo.findById(id).orElse(null);
        return auto;
    }

    @Override
    public void editAuto(Long idOriginal, Long idNueva, String nuevaMarca, double nuevoPrecio) {
        //busco  el objeto original
        Auto auto = this.findAuto(idOriginal);
            
        //proceso de modificación a nivel lógico
        auto.setId(idNueva);
        auto.setMarca(nuevaMarca);
        auto.setPrecio(nuevoPrecio);
        
        //guardar los cambios
        this.saveAuto(auto);
    }

}
