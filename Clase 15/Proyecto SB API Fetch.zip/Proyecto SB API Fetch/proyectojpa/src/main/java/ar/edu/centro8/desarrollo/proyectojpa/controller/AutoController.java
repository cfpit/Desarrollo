package ar.edu.centro8.desarrollo.proyectojpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.service.IAutoService;

@Controller
public class AutoController {
    
    @Autowired
    private IAutoService autoServ;
    
    // Página principal - mostrar todos los autos y formulario
    @GetMapping("/")
    public String mostrarIndex(Model model) {
        List<Auto> autos = autoServ.getAutos();
        model.addAttribute("autos", autos);
        model.addAttribute("nuevoAuto", new Auto());
        return "index";
    }
    
    // Crear nuevo auto
    @PostMapping("/autos/crear")
    public String crearAuto(@ModelAttribute Auto auto, RedirectAttributes redirectAttributes) {
        try {
            autoServ.saveAuto(auto);
            redirectAttributes.addFlashAttribute("mensaje", "El auto fue creado correctamente");
            redirectAttributes.addFlashAttribute("exito", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al crear el auto: " + e.getMessage());
            redirectAttributes.addFlashAttribute("exito", false);
        }
        return "redirect:/";
    }
    
    // Mostrar formulario de edición
    @GetMapping("/autos/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        try {
            Auto auto = autoServ.findAuto(id);
            if (auto != null) {
                model.addAttribute("auto", auto);
                return "editar";
            } else {
                redirectAttributes.addFlashAttribute("mensaje", "Auto no encontrado");
                redirectAttributes.addFlashAttribute("exito", false);
                return "redirect:/";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al buscar el auto: " + e.getMessage());
            redirectAttributes.addFlashAttribute("exito", false);
            return "redirect:/";
        }
    }
    
    // Actualizar auto
    @PostMapping("/autos/actualizar")
    public String actualizarAuto(@ModelAttribute Auto auto, RedirectAttributes redirectAttributes) {
        try {
            // Usar el método existente del servicio para editar
            autoServ.editAuto(auto.getId(), auto.getId(), auto.getMarca(), auto.getPrecio());
            redirectAttributes.addFlashAttribute("mensaje", "El auto fue actualizado correctamente");
            redirectAttributes.addFlashAttribute("exito", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al actualizar el auto: " + e.getMessage());
            redirectAttributes.addFlashAttribute("exito", false);
        }
        return "redirect:/";
    }
    
    // Eliminar auto
    @GetMapping("/autos/eliminar/{id}")
    public String eliminarAuto(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            autoServ.deleteAuto(id);
            redirectAttributes.addFlashAttribute("mensaje", "El auto fue eliminado correctamente");
            redirectAttributes.addFlashAttribute("exito", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al eliminar el auto: " + e.getMessage());
            redirectAttributes.addFlashAttribute("exito", false);
        }
        return "redirect:/";
    }
}
