package ar.edu.centro8.desarrollo.proyectojpa1a1unidireccional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyectojpa1a1UnidireccionalApplicationTests {

	@Test
	void contextLoads() {
	}

}